<?php
// powerball.php
// Returns latest draw + last 10 draws (if available) as JSON
// Strategy: try official data feeds (Socrata), then fallback to scraping official site HTML

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function fetch_url($url, $timeout=10) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; LotteryUpdate/1.0)');
    $res = curl_exec($ch);
    curl_close($ch);
    if ($res === false) return null;
    return $res;
}

function try_socrata_powerball() {
    // NY Open Data Socrata dataset for Powerball (commonly used)
    $url = 'https://data.ny.gov/resource/d6yy-54nr.json?$order=draw_date DESC&$limit=10';
    $json = fetch_url($url);
    if (!$json) return null;
    $data = json_decode($json, true);
    if (!is_array($data) || count($data) === 0) return null;
    $out = [];
    foreach ($data as $row) {
        $raw = $row['winning_numbers'] ?? ($row['winning_number'] ?? null);
        $numbers = [];
        if (is_string($raw)) {
            preg_match_all('/\d+/', $raw, $m);
            $numbers = array_map('intval', $m[0]);
        } elseif (isset($row['numbers']) && is_array($row['numbers'])) {
            $numbers = array_map('intval', $row['numbers']);
        }
        $out[] = [
            'drawDate' => $row['draw_date'] ?? ($row['drawDate'] ?? null),
            'numbers' => $numbers,
            'raw' => $row
        ];
    }
    return $out;
}

function scrape_official_powerball() {
    // Fallback scraping of powerball.com recent results page
    $url = 'https://www.powerball.com/games/home';
    $html = fetch_url($url);
    if (!$html) return null;
    $results = [];
    if (preg_match_all('/(\b\d{1,2}\b[\s,\u00A0\-]*\b\d{1,2}\b[\s,\u00A0\-]*\b\d{1,2}\b[\s,\u00A0\-]*\b\d{1,2}\b[\s,\u00A0\-]*\b\d{1,2}\b(?:[\s,\u00A0\-]*\b\d{1,2}\b)?)/', $html, $matches)) {
        foreach ($matches[0] as $seq) {
            preg_match_all('/\d{1,2}/', $seq, $nums);
            $nums = array_map('intval', $nums[0]);
            if (count($nums) >= 5 && count($nums) <= 6) {
                $results[] = ['drawDate' => null, 'numbers' => $nums, 'raw' => $seq];
            }
            if (count($results) >= 10) break;
        }
    }
    return $results ?: null;
}

$output = try_socrata_powerball();
if (!$output) $output = scrape_official_powerball();

if (!$output) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch Powerball results']);
    exit;
}

echo json_encode([
    'source' => 'official-scrape',
    'count' => count($output),
    'draws' => array_slice($output, 0, 10)
], JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
