<?php
// euromillions.php
// Returns latest draw + last 10 draws
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function fetch_url($url, $timeout=10) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; LotteryUpdate/1.0)');
    $res = curl_exec($ch);
    curl_close($ch);
    if ($res === false) return null;
    return $res;
}

function try_github_euromillions() {
    $url = 'https://raw.githubusercontent.com/pedro-mealha/euromillions-api/master/data/draws.json';
    $json = fetch_url($url);
    if (!$json) return null;
    $data = json_decode($json, true);
    if (!is_array($data) || count($data) === 0) return null;
    // assume draws are chronological; sort desc by date
    usort($data, function($a,$b){
        $da = strtotime($a['date'] ?? ($a['draw_date'] ?? '0'));
        $db = strtotime($b['date'] ?? ($b['draw_date'] ?? '0'));
        return $db - $da;
    });
    $out = [];
    foreach (array_slice($data,0,10) as $row) {
        $raw = $row['numbers'] ?? ($row['winning_numbers'] ?? null);
        $numbers = [];
        if (is_string($raw)) {
            preg_match_all('/\d+/', $raw, $m);
            $numbers = array_map('intval', $m[0]);
        } elseif (is_array($raw)) {
            $numbers = array_map('intval', $raw);
        } elseif (isset($row['draw']) && is_array($row['draw'])) {
            $numbers = array_map('intval', $row['draw']);
        }
        $out[] = [
            'drawDate' => $row['date'] ?? ($row['draw_date'] ?? null),
            'numbers' => $numbers,
            'raw' => $row
        ];
    }
    return $out;
}

function scrape_official_euromillions() {
    // Fallback: use euro-millions.com results page
    $url = 'https://www.euro-millions.com/results';
    $html = fetch_url($url);
    if (!$html) return null;
    $results = [];
    if (preg_match_all('/(\b\d{1,2}\b(?:[\s,\u00A0\-]*\b\d{1,2}\b){4,7})/', $html, $matches)) {
        foreach ($matches[0] as $seq) {
            preg_match_all('/\d{1,2}/', $seq, $nums);
            $nums = array_map('intval', $nums[0]);
            if (count($nums) >= 5) {
                $results[] = ['drawDate' => null, 'numbers' => $nums, 'raw' => $seq];
            }
            if (count($results) >= 10) break;
        }
    }
    return $results ?: null;
}

$output = try_github_euromillions();
if (!$output) $output = scrape_official_euromillions();

if (!$output) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch EuroMillions results']);
    exit;
}

echo json_encode([
    'source' => 'official-scrape',
    'count' => count($output),
    'draws' => array_slice($output, 0, 10)
], JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
