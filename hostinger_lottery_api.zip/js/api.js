// api.js — Hostinger backend endpoints in /api/*.php
const endpoints = {
  powerball: '/api/powerball.php',
  megamillions: '/api/megamillions.php',
  euromillions: '/api/euromillions.php'
};

function setStatus(msg) {
  const s = document.getElementById('status');
  if (s) s.textContent = msg;
}

async function fetchAndRender(name) {
  setStatus('Fetching ' + name + '...');
  try {
    const res = await fetch(endpoints[name], { cache: 'no-store' });
    if (!res.ok) throw new Error('Network response was not ok: ' + res.status);
    const json = await res.json();
    if (json.error) throw new Error(json.error);

    const draw = (json.draws && json.draws[0]) || null;
    const numbers = draw && Array.isArray(draw.numbers) ? draw.numbers.join(' ') : '—';
    const date = draw && (draw.drawDate || (draw.raw && (draw.raw.draw_date || draw.raw.date))) || '—';

    if (name === 'powerball') {
      document.getElementById('powerballNumbers').textContent = numbers;
      document.getElementById('powerballDate').textContent = date;
    } else if (name === 'megamillions') {
      document.getElementById('megaNumbers').textContent = numbers;
      document.getElementById('megaDate').textContent = date;
    } else if (name === 'euromillions') {
      document.getElementById('euroNumbers').textContent = numbers;
      document.getElementById('euroDate').textContent = date;
    }
    setStatus('Last updated: ' + new Date().toLocaleString());
  } catch (err) {
    console.error(err);
    setStatus('Error fetching ' + name + ': ' + err.message);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btnPowerball').addEventListener('click', () => fetchAndRender('powerball'));
  document.getElementById('btnMega').addEventListener('click', () => fetchAndRender('megamillions'));
  document.getElementById('btnEuro').addEventListener('click', () => fetchAndRender('euromillions'));
});
