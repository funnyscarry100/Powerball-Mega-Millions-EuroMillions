Hostinger PHP API bundle — Live Lottery Updates (Powerball, Mega Millions, EuroMillions)
======================================================================================

Files to upload:
- /api/powerball.php
- /api/megamillions.php
- /api/euromillions.php
- /js/api.js   (replace your existing api.js with this Hostinger-targeted version)

How it works:
- Each PHP endpoint tries free, public sources (Socrata / GitHub datasets) first.
- If free feeds fail, the scripts fall back to scraping official pages.
- Endpoints return JSON with latest draw first and up to 10 recent draws.

Upload instructions (Hostinger):
1. Log in to Hostinger -> File Manager (or use FTP).
2. Navigate to your site root (public_html or www).
3. Create folder /api and upload the three .php files into it.
4. Upload /js/api.js to your site's /js/ folder, replacing existing api.js.
5. Ensure files have correct permissions (644).
6. Visit: https://yourdomain.com/api/powerball.php to test.

Notes:
- Scraping relies on public HTML structure and may break if the official sites change. Prefer to use official open-data feeds where available.
- If you want scheduled automatic fetch/caching, consider a cron job or a small cache file updated periodically.
- No API keys are included. If you later use RapidAPI, store keys server-side in Hostinger config (not in JS).

Support:
- If a PHP endpoint returns an error, copy the URL and paste the exact response here and I will debug.

